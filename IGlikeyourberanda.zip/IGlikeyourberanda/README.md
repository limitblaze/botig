<b>####### Instagram-Tools #######</b><br>
<b>Thanks for ccocot and SGB-TEAM</b><br>
<b>#############################</b><br><br>

Tools :<br>
=> Node V8 (Cek Website Resmi)<br>
=> Npm (For Linux & Android : apt-get install npm)<br><br>

Tutorial :
1) Open CMD/Terminal Linux
2) Extract Instagram-Tools Files If Still In ZIP Extensions
2) Choose Your Directory Instagram-Tools
   - Linux/Android : Terminal => cd dir/Instagram-Tools
   - Windows : CMD => cd dir/Instagram-Tools
   Note : Recommend Put File In Your Directory Document
4) Then Type: npm install
5) After That Run The Files That You Want.
   Example: node botlike2.js

Okay So Simple Tutorial
